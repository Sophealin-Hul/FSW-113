let studentGrades = [90, 80, 88,98];
var gradeArray = [...studentGrades];
console.log(gradeArray);