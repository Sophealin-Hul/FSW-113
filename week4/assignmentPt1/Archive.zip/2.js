let myGrade = 99;
var result = myGrade;
console.log(result);