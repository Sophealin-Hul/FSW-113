var studentName = "James Moore";
var dob = "02/02/2002";
var studentInfo = {
    studentName,
    dob
};
console.log(studentInfo);