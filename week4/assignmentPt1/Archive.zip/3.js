let studentGrades = [90, 80, 88, 98];
var maxGrade = Math.max(...studentGrades);
console.log(maxGrade);