let studentGrades = [...[,,]];
console.log(studentGrades);