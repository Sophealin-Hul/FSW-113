let studentGrades = [90,80,88,98];
var result = Math.max(...studentGrades);
console.log(result);
console.log(result, is instanceof array);
