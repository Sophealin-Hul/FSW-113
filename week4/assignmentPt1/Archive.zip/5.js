let myhouseNumber = [..."8976", "AB", "CDEF"];
console.log(myhouseNumber);