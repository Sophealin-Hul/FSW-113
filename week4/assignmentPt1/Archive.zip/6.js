var studentName = "James Moore";
var dob = "02/02/2002";
var studentInfo = {
    [studentName]: studentName,
    [dob]: dob
};
console.log(studentInfo);