number = 10;
console.log(name);
"use strict";
console.log("from ext", number);
replaceNumber = 10;
var number = 10;5
console.log("from ext", number);
replaceNumber = 10;
var number = 10;
exports.Number = numbe5r;
console.log("from ext",ext.Number);
Add: 
var name = "John";
exports.Number = number;
exports.Name = name;
console.log("from ext", ext.Number);
console.log("from ext", ext.Name);
