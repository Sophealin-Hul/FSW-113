const ext = require("./external.js");
console.log("from ext", number);
"use strict";
console.log("from ext", number);