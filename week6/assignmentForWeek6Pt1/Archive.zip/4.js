const myArrays = [2, 4, 6, 8];
const newArray = myArrays.map(item => item * 2);
console.log(myArrays, newArray);



