//8
let grades = [90, 98, 78, 99];
let studentGrades = grades.map(v => v * 0.90);
console.log(studentGrades);