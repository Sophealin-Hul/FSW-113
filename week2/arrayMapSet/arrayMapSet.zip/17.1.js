//17.1
let student = {name: 'John Masson'};
let adjunct = {name: 'Dave Larson'};
let people = new Set();
people.add(student);
people.add(adjunct);
console.log(people.size);