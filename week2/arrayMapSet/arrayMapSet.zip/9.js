//9
let grades = [90, 98, 78, 99];
let studentGrades = grades;
console.log(studentGrades);