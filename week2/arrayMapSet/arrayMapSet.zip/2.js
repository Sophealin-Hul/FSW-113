//2
let studentArray = Array.of(10);
console.log(studentArray.length);
console.log(studentArray);