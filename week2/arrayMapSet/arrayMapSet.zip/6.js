//6
let grades = [90, 98, 78, 99];
let studentGrades = grades.find(v => v >= 90)
console.log(studentGrades);