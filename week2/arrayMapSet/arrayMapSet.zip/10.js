//10
let student = {name: 'John Masson'};
let adjunct = {name: 'Dave Larson'};
let people = new Map();
people.set(student.name, 'Student');
people.set(adjunct.name, 'Adjunct');
console.log(people);